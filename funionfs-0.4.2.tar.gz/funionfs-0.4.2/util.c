/*
    FUNIONFS: UNIONFS over FUSE Usermode filesystem
    Copyright (C) 2005-2006  Stephane APIOU <stephane.apiou@free.fr>

    utils.c: fonctions of general use. 

    This program can be distributed under the terms of the GNU GPL.
    See the file COPYING.
*/

#include <string.h>

int getrightstr(char *str, char *substr)
{
	char *pend, *psend;

	pend = str + strlen(str) - 1;
	psend = substr + strlen(substr) - 1;

	if (strlen(substr) > strlen(str))
		return 0;

	while (psend >= substr)
	{
		if (*pend != *psend)
			break;
		pend--;
		psend--;
	}
	if (psend < substr)
		return strlen(substr);
	return 0;
}
